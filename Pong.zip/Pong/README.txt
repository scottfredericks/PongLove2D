Author: Scott Fredericks

This is just a simple (single player) Pong clone created using Lua and Love2D. For the fun of it, I decided to add varying gravity, the direction of which is shown in the top left corner of the screen.
It plays like any other pong game, with the height of your "paddle" is controlled by the mouse. The first player to 10 points wins.
Sound effects were made using FamiTracker and Bfxr, both of which are freely available.

CONTROLS:
p: pause/unpause
n: starts new game, clears score
esc: quits program

Note: You can resize the window manually. Doing so will scale the strength of gravity and may alter the difficulty.